import streamlit as st
def print_header():
    #-- Header Section
    st.markdown("""
    <style>
    .block-container
    {
      background-color:#CEFAFE;
      color:black;
      padding-top:50px;
      padding-bottom:10px;
    }
    </style>
    """, unsafe_allow_html=True);
    col_logo, col_title = st.columns([2, 8]);
    with col_logo:
        st.image("images/logo6.png");
    with col_title:
        st.markdown("# Sales Analytics Dashboard App ");
    st.divider();