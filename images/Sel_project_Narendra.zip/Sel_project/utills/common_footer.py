import streamlit as st
import pandas as pd
def print_footer():
    cur_dt = pd.Timestamp.now()
    st.markdown(f"""
         <div style='width:100;background-color:#27272A;color:white;text-align:center;min-height:50px;padding-top:10px;'>
         <div style='width:50%;float:left;'>&copy; Copyright {cur_dt.year} to Sales Analytics Dashboard App</div>
           <div style='width:50%;float:left;'>Developed By: Er. Narendra Kumar</div>""", unsafe_allow_html=True)

