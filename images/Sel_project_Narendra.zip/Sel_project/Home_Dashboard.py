import streamlit as st
import pandas as pd
import utills.common_header as ch
import utills.common_footer as cf
st.set_page_config(page_title="Welcome to Salse analytics project",
                   page_icon="images/6821002 (1).png",
                   layout="wide");
#header section
ch.print_header();
# Welcome Section
st.markdown("## Welcome 📈")
st.write("""
**Warm Regards**- “Welcome to your Sales Analytics Dashboard — a powerful space designed to transform data into 
decisions and insights into success. Here, every chart reveals opportunities, every number tells a story, and every 
report guides you toward smarter strategies. We are delighted to have you onboard, ready to explore the tools that make
your sales journey clearer, faster, and more rewarding. Together, let’s unlock growth, celebrate milestones, and shape 
a future driven by confidence and clarity.” """)
st.divider();

#-- image
col1,col2,col3=st.columns(3);
with col1:
    st.image("images/h4_image.jpg",width=400)
with col2:
    st.image("images/h2_image.jpg",width=500)
with col3:
    st.image("images/h3_image.jpg",width=500)

# -- Features Section
col_feat,col_aim,col_visual=st.columns(3);
with col_feat:
    st.info("""### ⚙️ Features
- Real-time data visualization  
- Revenue metrics  
- Team performance  
- Automated reporting  
- Activity monitoring  
- Role-based views  
    """);
with col_aim:
    st.success("""### 🚀 Our Aim
- Business clarity  
- Efficiency improvement  
- Performance tracking  
- Data-driven culture  
- Strategic growth  
- Efficiency & automation  
""")
with col_visual:
    st.warning("""### 🎯 Our Objectives
- Data Security & Accuracy 
- Collaboration & Sharing 
- Custom Filters & Drill-Down
- Organize sales data for accurate analysis
- Measure overall sales and profit performance
""")
st.divider()

#-- Facts

c1,c2,c3,c4=st.columns(4);
c1.metric("**Total Accounts**",2104)
c2.metric("**Order per Months**",37)
c3.metric("**Growth Rate**",174.4,"+8.29%")
c4.metric("**Loss Rate**",63.12,"-3%");
st.divider();

#-- Project Flow
st.markdown("## 🔄 Project Flow")
c1,c2,c3,c4,c5,c6,c7=st.columns([2,1,2,1,2,1,2])
c1.button("**🗂️ Project Dataset**")
c2.markdown("<div style='font-size:25px;padding-top:4px;'>➡️</div>",unsafe_allow_html=True)
c3.button("**📱 sales Analitics Apps**")
c4.markdown("<div style='font-size:25px;padding-top:4px;'>➡️</div>",unsafe_allow_html=True)
c5.button("**📊 Dataset Analysis**")
c6.markdown("<div style='font-size:25px;padding-top:4px;'>➡️</div>",unsafe_allow_html=True)
c7.button("**📑 Reports & Charts**")
st.divider()

#-- Footer Section
cf.print_footer();
