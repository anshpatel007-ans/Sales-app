"""import streamlit as st
st.success("Record saved successfully.")
st.info("Mobile number must have 10 digits.")
st.error("Record not saved.")
st.warning("Please enter your name.")
st.divider()
st.metric("Total Records",50000,"+15%")
st.metric("Customers",2300,"+20%")
st.metric("Total Profit",20000,"+6%")
"""

"""
import streamlit as st
if "count" not in st.session_state:
    st.session_state.count=0
if st.button("Click Here"):
    st.session_state.count=st.session_state.count
    st.session_state.count+=1
st.write("Button clicked; "+
         str(st.session_state.count)+" Times.");
"""

#start assessment section
import streamlit as st
st.title("Selse analytics Dashboard")
if "step" not in st.session_state:
    st.session_state.step=1;
if st.session_state.step==1:
    with st.form("Personal Det"):
        st.subheader("Step-1: Personal Details")
        name=st.text_input("Enter Your Name: ");
        age=st.number_input("Enter your Age: ")
        btn=st.form_submit_button("Save & Next");
    if btn:
        st.session_state.name=name
        st.session_state.age=age
        st.session_state.step+=1
        st.rerun()
if st.session_state.step==2:
    with st.form("Routine_det"):
        st.subheader("Step-2: Daily Routine Details")
        sleep_hours=st.number_input("How many hours you sleep?: ");
        work_hours=st.number_input("How many hours you work ?: ")
        btn=st.form_submit_button("Save & Print");
    if btn:
        st.session_state.sleep_hours=sleep_hours
        st.session_state.work_hours=work_hours
        st.session_state.step+=1
        st.rerun()
if st.session_state.step==3:
    st.text("Name is: "+st.session_state.name)
    st.text("Age is: " + str(st.session_state.age))
    st.text("Sleep hours: " + str(st.session_state.sleep_hours))
    st.text("Work hours: " + str(st.session_state.work_hours))
#End Assessement section
