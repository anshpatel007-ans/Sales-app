import streamlit as st;
import pandas as pd;
import numpy as np;
import utills.common_header as ch;
import utills.common_footer as cf;
st.set_page_config(page_title="Welcome to Project Name",
                   page_icon="images/mylogo.png",
                   layout="wide");
ch.print_header();
#reading dataset in dataframe
dataset_file_name="data/uploaded_dataset.csv";
df_dataset=pd.read_csv(dataset_file_name);
st.markdown("<center style='color:navy;font-size:28px;"
            "font-weight:bold'>Data Cleaning & Analysis</center>",
            unsafe_allow_html=True);
with st.container(border=True):
    st.subheader("Currenet Dataset is:-");
    st.success(dataset_file_name);
    col1,col2=st.columns(2);
    with col1:
       st.markdown(f"**Total Rows:** {df_dataset.shape[0]}");
    with col2:
       st.markdown(f"**Total Columns:** {df_dataset.shape[1]}");
st.markdown("<center style='color:maroon;font-size:22px;font-weight:bold'>Overview of Data</center>",
            unsafe_allow_html=True);
with st.container(border=True):
     col_name,col_value,col_null=st.columns([2,1,5]);
     with col_name:
         st.markdown("""
         - Total Missing values
         - Total Duplicate Records 
         - Total Numeric Features
         - Total Property Types
         """)
     with col_value:
         total_dup_count=df_dataset.duplicated(subset=df_dataset.columns.drop("Order_ID"),keep=False).sum();
         st.markdown(f"""
         - {df_dataset.isnull().sum().sum()}
         - {total_dup_count}
         - {len(df_dataset.select_dtypes(include="int").columns)}
         - {df_dataset.groupby("Order_ID")["Order_ID"]
                     .count().count()}
         """)
st.markdown("<center style='color:green;font-size:22px;"
            "font-weight:bold'>Cleaning Operation</center>",
            unsafe_allow_html=True);
with st.container(border=True):
      numeric_fill=st.radio("**Fill Missing numeric Values.** Please choose one value to fill-",
                    ["Mean","Median","Zero"]);
      string_fill = st.radio("**Fill Missing String Values.** Please choose one value to fill-",
                    ["Unknown", "Not Applicable"]);
      rem_missing=st.checkbox("**Remove record having missing values.**");
      rem_duplicate=False;
      if total_dup_count>0:
          rem_duplicate=st.checkbox("**Remove duplicate Records.**")
      col1,col2=st.columns(2);
      with col1:
          btn_clean=False;
          btn_clean=st.button("Start Data Cleaning",type="primary");
      with col2:
          btn_show_dupli=False;
          if total_dup_count>0:
           btn_show_dupli=st.button("Show Duplicate Records");
      if btn_show_dupli:
          st.markdown("<center style='color:navy;font-family:verdana;font-size:22px;font-weight:bold'>"
                            "Details of duplicate Records</center>",unsafe_allow_html=True);
      df_duplicate_rec=df_dataset[df_dataset.duplicated(df_dataset.columns.drop("Order_ID"),keep=False)];

      #adding a custom columns to dataframe for custom index
      df_duplicate_rec["SRNo"]=np.arange(1,total_dup_count+1);
      df_duplicate_rec.set_index("SRNo",inplace=True)
      st.dataframe(df_duplicate_rec);
if btn_clean:
    numeric_cols=df_dataset.select_dtypes(include=["int","float"]).columns;
    string_cols=df_dataset.select_dtypes(include="object").columns;
    if rem_duplicate==True:
        df_dataset.drop_duplicates(df_dataset.columns.drop("Order_ID"),keep=False,inplace=True);
    if rem_missing==True:
        df_dataset.dropna(inplace=True)
    elif numeric_fill=="Mean":
        for col in numeric_cols:
            df_dataset[col]=(df_dataset[col].fillna(df_dataset[col].mean(),inplace=True));
    elif numeric_fill=="Median":
        for col in numeric_cols:
            df_dataset[col]=(df_dataset[col].fillna(df_dataset[col].median(),inplace=True));
    elif numeric_fill=="Zero":
        st.write("Filling Zero");
        df_dataset[numeric_cols]=(df_dataset[numeric_cols].fillna(0));
    if string_fill=="Unknown":
        df_dataset[string_cols]=(df_dataset[string_cols].fillna("Unknown"));
    elif string_fill=="Not Applicable":
        df_dataset[string_cols]=(df_dataset[string_cols].fillna("Not Applicable"))
    # Updating csv file after performing data cleaning
    st.subheader("Clean dataset is-");
    st.dataframe(df_dataset);
    df_dataset.to_csv(dataset_file_name,index=False);
    st.success("Congratulations!! Data cleaning""completed successfully.");
    st.info("Please click of below button to proceed ""for Data Analysis");
    st.markdown("""<a href='Data_Analysis'><div style='
                color:white;text-decoration:none;font-size:20px;'>
                Proceed to Data Analysis</div></a>""",unsafe_allow_html=True)
    #st.write("Numeric Columns: ")
    #st.write(numeric_cols)
    #st.write("String Columns: ")
    #st.write(string_cols);
    #st.write("Data Type of Price Columns: "+str(df_dataset(price)))
cf.print_footer();