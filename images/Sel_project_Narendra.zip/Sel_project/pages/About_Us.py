import streamlit as st
import utills.common_header as ch
import utills.common_footer as cf
st.set_page_config(page_title="Welcome to Salse analytics project",
                   page_icon="images/6821002 (1).png",
                   layout="wide");
ch.print_header()
with st.container(border=True):
    st.markdown("""
    <div style="background-color:#024A70; color:white;padding-center:50px;text-align:center; font-size:30px;
    font-weight:bold;">About Us</div>""",unsafe_allow_html=True)
col1,col2=st.columns([4,6])
with col1:
    with st.container(border=True):
        st.markdown("""
        <div style=" border-radius:5px;">
        <span style="font-size:40px;"></span>
        <span style="font-size:30px; font-weight:bold;">💬 Project Name<br>
        <p style="padding-left:60px;font-size:20px;">Sales Analytics Dashboard</p>
        </span></div>""",unsafe_allow_html=True)
    with st.container(border=True):
        st.markdown("""
        <div style="border-radius:5px;">
        <span style="font-size:40px;"></span>
        <span style="font-size:30px; font-weight:bold;">🆕 Project Version<br>
        <p style="padding-left:60px;font-size:20px;">Version 3.0 – “Insight360 Evolution”</p>
        </span></div>""",unsafe_allow_html=True)
    with st.container(border=True):
        st.markdown("""
        <div style="border-radius:5px;">
        <span style="font-size:40px;"></span>
        <span style="font-size:30px; font-weight:bold;">⚙️ Technology Used<br>
        <p style="padding-left:60px;font-size:20px;">Sales Analytics Dashboard</p>
        </span></div>""",unsafe_allow_html=True)
        tc1, tc2 = st.columns([5, 5])
        with tc1:
            st.markdown("""
                            <div style="font-size:16px;">
                            🐍 Python <br>
                            🐼 Pandas<br>
                            🔢 NumPy<br>
                            🗂️ CSV Data Processing <br>  
                            </div>
                            """, unsafe_allow_html=True)
        with tc2:
            st.markdown("""
                            <div style="font-size:16px;">
                            🌐 Streamlit<br>
                            📈 Plotly<br>
                            📈 Matplotlib<br>
                            </div>
                            """, unsafe_allow_html=True)
    with st.container(border=True):
        st.markdown("""
        <div style="color:white; background-color:#024A70; font-size:20px;
        padding-top:5px; border-radius:5px;">
        <p>🚀 Our Mission</p>
        </div>
        """,unsafe_allow_html=True)
        img2, txt2 = st.columns([3,7])
        with img2:
            st.image("images/logo3.png")
        with txt2:
            st.text("""Our mission is to empower businesses with clear, data‑driven insights that transform sales performance into sustainable growth. By combining advanced analytics, AI forecasting, and intuitive dashboards, we aim to simplify decision‑making, strengthen customer relationships, and unlock new opportunities for success.""")
    with st.container(border=True):
        st.markdown("""
        <div style="color:white; background-color:#024A70; font-size:20px;
        padding-top:5px; border-radius:5px;">
        <p>👨‍💻 About Developer</p>
        </div>
        """,unsafe_allow_html=True)
        img3, txt3 = st.columns([3,7])
        with img3:
            st.image("images/my12.jpg")
        with txt3:
            st.text("""
            Name: Er. Narendra
            Mob: 8127649813
            Email: narendra8127@gmail.com""")




with col2:
    with st.container(border=True):
        st.markdown("""
        <div style="color:white; background-color:#024A70; font-size:20px;
        padding-top:5px; border-radius:5px;">
        <p><b>🎯 Project Objective</b></p>
        </div>
        <p style="font-size:16px; text-align:justify;">
        Sales dashboards and analytics are the set of those important KPIs which are required to monitor the sales 
        performance and growth of your company. Monitoring these KPIs help you in improving the sales strategy planning
        and forecasting for future sales predictions.<br>
        Beyond Key believes in the value of “Happy Teams Members, Happy Clients”. As a global IT consulting and 
        software services company, we focus on developing scalable software solutions and products which exceed our 
        customer’s expectations.<br>
        We are a Microsoft Solutions Partner company and been awarded “The Great Place to Work” certification. Since 
        our founding in 2005, our team has grown to over 350+ talented software professionals. We develop and design IT
        solutions for our clients across the US, Canada, Europe, Australia.
        </p>
        """,unsafe_allow_html=True)
        cl1,cl2,cl3,cl4=st.columns([2,2,2,2])
        with cl1:
            with st.container(border=True):
                st.markdown("""<div style="background-color:#2B7FFF;color:white;font-size:20px; text-align:center;">
                💬
                <br>Analyze</div>""",unsafe_allow_html=True)
        with cl2:
            with st.container(border=True):
                st.markdown("""<div style="background-color:#2B7FFF;color:white;font-size:20px; text-align:center;">
                💬
                <br>Visualize</div>""",unsafe_allow_html=True)
        with cl3:
            with st.container(border=True):
                st.markdown("""<div style="background-color:#2B7FFF;color:white;font-size:20px; text-align:center;">
                💬
                <br>optimize</div>""",unsafe_allow_html=True)
        with cl4:
            with st.container(border=True):
                st.markdown("""<div style="background-color:#2B7FFF;color:white;font-size:20px; text-align:center;">
                💬
                <br>Achieve</div>""",unsafe_allow_html=True)

    with st.container(border=True):
        st.markdown("""
        <div style="color:white; background-color:#024A70; font-size:20px;
        padding-top:5px; border-radius:5px;">
        <p><b>⚙️ Key Features</b></p>
        </div>
        """,unsafe_allow_html=True)
        sc1, sc2 = st.columns([5, 5])
        with sc1:
                st.markdown("""
                    <div style="font-size:16px;">
                    📊 Real-Time Data Visualization   <br>
                    🔍 Advanced Filters & Drill-Downs   <br>
                    📈 Revenue & Performance Metrics   <br>
                    📑 Automated Reporting   <br>
                    ⚡ User-Friendly Interface  
                    </div>
                    """, unsafe_allow_html=True)
        with sc2:
                st.markdown("""
                    <div style="font-size:16px;">
                    🔒 Secure Role-Based Access   <br>
                    🤝 Collaboration Tools   <br>
                    ⏱️ Pipeline & Conversion Tracking  <br>
                    📡 Forecasting & Predictive Insights <br>
                    📊 Real-Time Data Visualization
                    </div>
                    """, unsafe_allow_html=True)
    with st.container(border=True):
        st.markdown("""
        <div style="color:white; background-color:#024A70; font-size:20px;
        padding-top:5px; border-radius:5px;">
        <p><b>🌟 Our Vision</b></p>
        </div>
        """,unsafe_allow_html=True)
        img1, txt1 = st.columns([3,7])
        with img1:
            st.image("images/logo4.png")
        with txt1:
            st.text("""
            Our vision is to empower businesses with a modern, intelligent Sales Analytics Dashboard that transforms data into clarity, decisions into growth, and insights into long‑term success. By fostering a culture of data‑driven decision‑making, we aim to simplify complexity, enhance efficiency, and support organizations inachieving sustainable sales excellence.
            """)

cf.print_footer()




