import os

import streamlit as st
import pandas as pd
import utills.common_header as ch
import utills.common_footer as cf
st.set_page_config(page_title="Welcome to Salse analytics project",
                   page_icon="images/6821002 (1).png",
                   layout="wide");
# Header Section
ch.print_header()
#st.divider()
#Start : Uploade dataset page
st.header("📂 Uploade DataSet for Analysis")
st.subheader("Step-1: Understand Required Formate & Sample Data")
with st.container(border=True):
    st.markdown("**Suggested Required Columns**")
    col_name,col_desc=st.columns([1,3])
    with col_name:
        st.markdown("""
        - Order_ID
        
        - Order_Data
        
        - Customer_Name
        
        - Customer_Type
        
        - Product_Name
        
        - Category
        
        - Region
        
        - City
        
        - State
        
        - Quantity
        
        - Sales
        
        - Profit
        
        - Payment_Mode
        """)
    with col_desc:
        st.markdown("""
        Unique Order Id
        
        Data of Order in yyyy-mm-dd formate   
             
        Name of Customer 
        
        Type of Customer (Regular/New)  
             
        Product name of Each Transection
        
        Product Category
        
        Sales Region
        
        City of Customer
        
        State of Customer
        
        Quantity Sold
        
        Total Sales Amount
        
        Profit Earned
          
        Payment Method (Cash,Card,UPI,etc.)
        """)
with st.container(border=True):
    col_icon,col_down=st.columns([1,6])
    with col_icon:
        st.image("images/excel_icon.jfif");
    with col_down:
        st.markdown("**Download Sample Dataset**")
        st.text("Set a template to understand formate of Dataset")
        with open("data/DataSet_name.csv","rb") as samp_file:
            st.download_button("Download Sample CSV",
                               data=samp_file,file_name="DataSet_File");
#Uploade Dataset
st.subheader("Step-2:📂 Uploade your Dataset")
with st.container(border=True):
    up_file=st.file_uploader(
        "**Choose or Drag & drop your dataset file:**",type=["csv"]);
    #validate uploaded dataset
    if up_file is not None:
        if up_file.name.endswith(".csv") or up_file.name.endswith(".CSV"):
            df_dataset=pd.read_csv(up_file);
            #showing preview..
            st.markdown("**Showing Preview of Uploaded Dataset:-**")
            st.dataframe(df_dataset.head())
            # Validate columns od dataset...
            allowed_cols_lst=["Order_ID","Order_Date","Customer_Name","Customer_Type","Product_Name","Category","Region","City","State","Quantity",
                              "Sales","Discount_Per","Profit","Payment_Mode","Order_Status"]
            missing_cols_lst=[];
            for allowed_cols in allowed_cols_lst:
                if allowed_cols not in df_dataset.columns:
                    missing_cols_lst.append(allowed_cols);
            if len(missing_cols_lst) > 0:
                st.error("Below columns are missing from your dataset-");
                st.write(missing_cols_lst);
                st.warning("Warning: Please update your dataset to solve above errors and try again to upload.");
            else:
                st.success("Your dataset is validated successfully.");
                if st.button("Save dataset & Proceed"):
                     df_dataset.to_csv("data/uploaded_dataset.csv",index=False)
                     st.switch_page("pages/view_Dataset.py")
        else:
            st.error("Invalid file format for Dataset. Only .csv format is allowed.");

#End : Uploade dataset page
# footer section
cf.print_footer()