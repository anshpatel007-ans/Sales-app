import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sb
from fontTools.diff import color

import utills.common_header as ch
import utills.common_footer as cf
import pandas as pd

st.set_page_config(page_title="Welcome to Sales Analytics",page_icon="images/saleslg.jpg",layout="wide")
ch.print_header()
dataset_file_name="Data/uploaded_dataset.csv"
df_dataset=pd.read_csv(dataset_file_name)
col_main,col_right=st.columns([8,2])
with col_main:
    with st.container(border=True):
        st.markdown("""<p style='text-align:center;background-color:blue;color:white;font:weight:bold;font-size:25px'>Data Visualization""",unsafe_allow_html=True)
    with st.container(border=True):
        col1,col2=st.columns(2)
        with col1:
          with st.container(border=True):
            fig,ax=plt.subplots(figsize=(8,5))
            ax.plot(df_dataset["Product_Name"],df_dataset["Product_Name"])
            plt.xlabel("Data",color="navy",fontsize=14)
            plt.ylabel("Data",color="navy",fontsize=14)
            plt.title("Product and price Analysis",color="red",fontsize=22)
            plt.tight_layout()
            st.pyplot(fig)
        with col2:
            with st.container(border=True):
                fig, ax = plt.subplots(figsize=(8, 5))
                df_chart = pd.DataFrame({})
                df_chart["Discount"] = df_dataset["Discount_Per"]
                sb.histplot(data=df_chart)
                plt.title("Discount_of_Product", color="red", fontsize=22)
                plt.tight_layout()
                st.pyplot(fig)
        col1,col2=st.columns(2)
        with col1:
           with st.container(border=True):
            fig,ax=plt.subplots(figsize=(8,5))
            ax.plot(df_dataset["Product_Name"],df_dataset["Product_Name"])
            plt.xlabel("Data",color="navy",fontsize=14)
            plt.ylabel("Data",color="navy",fontsize=14)
            plt.title("Product and price Analysis",color="red",fontsize=22)
            plt.tight_layout()
            st.pyplot(fig)
        with col2:
         with st.container(border=True):
            fig,ax=plt.subplots(figsize=(8,5))
            sb.countplot(data=df_dataset,
                         x="Discount_Per",
                         hue="Discount_Per")
            plt.xlabel("Availability")
            plt.ylabel("No of Properties")
            plt.title("Product Availability",color="red",fontsize=16)
            # df_chart=pd.DataFrame({})
            # df_chart["Discount"]=df_dataset["Discount"]
            # sb.histplot(data=df_chart,palette="Reds",hue="Discount")
            # plt.title("Discount_of_Product",color="red",fontsize=22)
            # plt.tight_layout()
            st.pyplot(fig)

with col_right:
    st.markdown("""<p style='background-color:blue;color:white;font:weight:bold;font-size:17px'>Customize Graphs""",unsafe_allow_html=True)
    st.text("")
    with st.container(border=True):
        st.text("Filter Portion")
cf.print_footer()