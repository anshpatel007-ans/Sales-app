import streamlit as st
import smtplib as sb
import email.message as em;
import utills.common_header as ch
import utills.common_footer as cf
st.set_page_config(page_title="Welcome to Salse analytics project",
                   page_icon="images/6821002 (1).png",
                   layout="wide");
ch.print_header()
st.subheader("Share Your Suggestions")
st.markdown("**We value your idease.Please share your suggestions for improvement below.**")
col1,col2=st.columns([6,4])
with col1:
    with st.form(""):
        name=st.text_input("**Name**",placeholder="Enter Your Full Name");
        email=st.text_input("**Email Id**",placeholder="example@email.com");
        mob=st.text_input("**Mobile No:**",placeholder="91+");
        select=st.selectbox("**Topic of te Suggestion**",["Select a Topic..",
                                                      "Product Features",
                                                      "Website Usability",
                                                      "Content Ideas"])
        sugg=st.text_area("**detailed Suggestions Message**",placeholder="Share your Detailed thoughts,ideas, or feedback here..",
                          height=100,max_chars=2100)
        b1,b2=st.columns([2,5])
        with b1:
            if st.button("Submit Suggestion"):
                # start sending Email
                sender_email = "jaikarannamdev@gmail.com";
                sender_app_pass = "uxzo smac qiii bhxx";
                msg = em.EmailMessage()
                msg["To"] =sender_email
                msg["From"] = sender_email;
                msg["Subject"] = "A New Suggestion Recieved";
                msg.set_content(f"""Hellow Admin,
                
                  You have recieved a new suggestion from a user of Salse Analytics Dashboard Project.
                
                  Topic of Feedback: {select}
                
                  Please Find below details-
                  
                  Name of Person:{name}
                  Email ID of Person: {email}
                  Contact Number Of Person: {mob}
                  Suggestion Message: {sugg}
                  
                  Thanks & Regards-
                  Development Team of Sales Analytics Dashboard App
                  
                  """);
                smtp = sb.SMTP("smtp.gmail.com", 587);
                smtp.starttls();
                smtp.login(sender_email, sender_app_pass);
                smtp.send_message(msg);
                smtp.quit();
        st.success("Your Suggestion is Saved Successfully.")

        with b2:
            reset=st.button("Reset")
with col2:
    st.image("images/sugges.jpg",use_container_width=True)
    st.image("images/feedback1.jpg",use_container_width=True)


cf.print_footer()