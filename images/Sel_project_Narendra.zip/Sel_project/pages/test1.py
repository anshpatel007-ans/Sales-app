import smtplib as sb;
import email.message as em;
import streamlit as st
sender_email="jaikarannamdev@gmail.com";
sender_app_pass="uxzo smac qiii bhxx";
msg=em.EmailMessage()
msg["To"]="vivekmaury76076@gmail.com";
msg["From"]=sender_email;
msg["Subject"]="Suggestion Recieved"
msg.set_content("""
This is test email message.""");
smtp=sb.SMTP("smtp.gmail.com",587);
smtp.starttls();
smtp.login(sender_email,sender_app_pass);
smtp.send_message(msg);
smtp.quit();
st.success("Email sent successfully.")
