import reportlab.platypus as rp;
import reportlab.lib.styles as rs
import reportlab.lib.colors as colors;
import streamlit as st

report_file_name="Sales_analytics_report.pdf";
# Opening an empty document file for writing content
my_pdf=rp.SimpleDocTemplate(report_file_name)
# Colling method to set style of content during writing
# Using paragraph module
style=rs.getSampleStyleSheet()
# creating an empty Python list to append all content for pdf
content_list=[]
img=rp.image("images/logo3.png",width=130,height=70);
content_list.append(img);
para=rp.Paragraph("Sales Analytics Dashboard Report",style["Title"])
content_list.append(para);
pr=rp.Paragraph("Sales Analytics level: Moderate",style["Normal"])
content_list.append(pr);
# Start Table
tab_data=[["Rno","Name"],["1","Rahul"],["2","Prachi"],["3","Raj"]]
tbl=rp.Table(tab_data,colWidths=70,rowHeights=20)
tbl_border_style=rp.TableStyle([('GRID',(0,0),(-1,-1),1, colors.pink),])
tbl.setStyle(tbl_border_style)
tbl_bg_style=rp.TableStyle([('BACKGROUND',(0,0),(-1,-1),colors.pink),])
tbl.setStyle(tbl_bg_style)
content_list.append(tbl);
# Burning (writing) list data into document file
my_pdf.build(content_list)
# opening file to download from buffer memory
with open(report_file_name,"rb") as file:
    st.download_button("Download Report",data=file,file_name="Report.pdf");

