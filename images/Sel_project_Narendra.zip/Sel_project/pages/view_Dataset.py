import streamlit as st
import pandas as pd
import numpy as np
import utills.common_header as ch
import utills.common_footer as cf
st.set_page_config(page_title="Welcome to Salse analytics project",
                   page_icon="images/6821002 (1).png",
                   layout="wide");
ch.print_header()
#st.subheader("Showing Information of Dataset:")
dataset_file_name="data/uploaded_dataset.csv";
df_dataset=pd.read_csv(dataset_file_name);
col1,col2=st.columns([8,2])
with col1:
    c1,p1=st.columns([2,6])
    with c1:
      st.subheader("Completed Steps")
      st.markdown("**First 5 Records**")
      st.markdown("**Last 5 Records**")
      st.markdown("**Complete Dataset**")

    with p1:
        st.subheader("Pre-loaded Dataset Information")
        st.success(f"Current Dataset: {dataset_file_name}")
        c2,p2=st.columns(2)
        with c2:
            with st.container(border=False):
               if st.button("**Analyze Dataset & Go to Dashboard**"):
                   st.switch_page("Home_Dashboard.py")
        with p2:
            with st.container(border=False):
               if st.button("**Proceed to Data Cleaning**",type="secondary"):
                   st.switch_page("pages/Data_cleaning.py")

        st.divider()
    st.subheader("Choose Any One Data for View")
    ch1,ch2,ch3=st.tabs(["First 5 Rows","Last 5 Rows","All Record of Dataset"])
    with ch1:
        st.dataframe(df_dataset.head());
    with ch2:
        st.dataframe(df_dataset.tail())
    with ch3:
        st.dataframe(df_dataset)

with col2:
    st.subheader("Dataset Overview")
    st.divider()
    st.markdown("**Dataset Information**")
    with st.container(border=True):
        st.markdown(f"**Total Observations** {len(df_dataset)}")
    with st.container(border=True):
        st.markdown(f"**Total Features** {df_dataset.shape[1]}")
    with st.container(border=True):
        x=len(df_dataset.select_dtypes(include="int").columns)
        y=len(df_dataset.select_dtypes(include="str").columns)
        st.markdown(f"**Total Numeric Features {x} and Total String Features {y}**")
    with st.container(border=True):
        st.line_chart(df_dataset.set_index("Product_Name")["Discount_Per"],height=350);

cf.print_footer()